const tg = window.Telegram?.WebApp;
tg?.ready();
tg?.expand();
try { tg?.setHeaderColor("#090a0e"); tg?.setBackgroundColor("#090a0e"); } catch {}

const products = [
  {id:"vtb-guide",name:"Гид по ВТБ",category:"Инструкции",price:199,description:"Авторская инструкция по основным возможностям приложения ВТБ.",icon:"🏦"},
  {id:"vk-guide",name:"Гид по VK",category:"Инструкции",price:149,description:"Советы по настройке и использованию ВКонтакте.",icon:"💬"},
  {id:"tbank-guide",name:"Гид по Т-Банку",category:"Инструкции",price:199,description:"Справочник по функциям приложения Т-Банка.",icon:"💳"},
  {id:"ios-icons",name:"Пакет иконок iOS",category:"Дизайн",price:249,description:"Авторский набор иконок для домашнего экрана.",icon:"🎨"},
  {id:"wallpapers",name:"Обои для iPhone",category:"Дизайн",price:99,description:"Коллекция оригинальных обоев для iPhone.",icon:"🌌"},
  {id:"iphone-checklist",name:"Чек-лист iPhone",category:"Инструкции",price:129,description:"Полезные настройки и рекомендации для нового iPhone.",icon:"📱"}
];
let category = "Все";
let cart = [];
const $ = s => document.querySelector(s);
const rub = n => new Intl.NumberFormat("ru-RU").format(n) + " ₽";

function render(){
  const q = $("#searchInput").value.trim().toLowerCase();
  const list = products.filter(p => (category==="Все" || p.category===category) && (p.name+" "+p.description).toLowerCase().includes(q));
  $("#itemCount").textContent = `${String(list.length).padStart(2,"0")} товара`;
  $("#products").innerHTML = list.length ? list.map(p => `
    <article class="product">
      <div class="product-icon">${p.icon}</div>
      <small>${p.category}</small><h3>${p.name}</h3><p>${p.description}</p>
      <div class="product-bottom"><span class="price">${rub(p.price)}</span><button class="add" data-add="${p.id}">Добавить</button></div>
    </article>`).join("") : `<div class="empty">Ничего не найдено. Попробуй другой запрос.</div>`;
  $("#cartCount").textContent = cart.reduce((n,x)=>n+x.qty,0);
}
function toast(message){
  const el=$("#toast");el.textContent=message;el.classList.add("show");
  clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>el.classList.remove("show"),2200);
}
$("#products").addEventListener("click",e=>{
  const id=e.target.dataset.add;if(!id)return;
  const found=cart.find(x=>x.id===id);
  if(found)found.qty++;else cart.push({id,qty:1});
  render();toast("Добавлено в корзину");
});
$("#searchInput").addEventListener("input",render);
$("#categories").addEventListener("click",e=>{
  const b=e.target.closest("[data-category]");if(!b)return;
  category=b.dataset.category;
  document.querySelectorAll(".chip").forEach(x=>x.classList.toggle("active",x===b));
  render();
});
document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>{
  const tab=b.dataset.tab;
  if(tab==="cart"){
    if(!cart.length){toast("Корзина пока пуста");return;}
    const total=cart.reduce((sum,x)=>sum+products.find(p=>p.id===x.id).price*x.qty,0);
    toast(`В корзине ${cart.reduce((n,x)=>n+x.qty,0)} шт. · ${rub(total)}. Оплата подключается.`);
  }else if(tab==="orders")toast("История заказов появится после подключения базы данных.");
  else if(tab==="profile")toast(tg?.initDataUnsafe?.user?.first_name ? `Привет, ${tg.initDataUnsafe.user.first_name}!` : "Профиль появится после подключения Telegram.");
  else window.scrollTo({top:0,behavior:"smooth"});
}));
$("#profileBtn").addEventListener("click",()=>toast("Профиль ADS STORE"));
render();
