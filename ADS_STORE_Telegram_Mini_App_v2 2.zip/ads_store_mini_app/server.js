import express from "express";
import path from "path";
import { fileURLToPath } from "url";

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const products = [
  { id: "vtb-guide", name: "Гид по ВТБ", category: "Инструкции", price: 199, description: "Авторская инструкция по основным возможностям приложения ВТБ." },
  { id: "vk-guide", name: "Гид по VK", category: "Инструкции", price: 149, description: "Подборка советов по настройке и использованию ВКонтакте." },
  { id: "tbank-guide", name: "Гид по Т-Банку", category: "Инструкции", price: 199, description: "Понятный справочник по функциям приложения Т-Банка." },
  { id: "ios-icons", name: "Пакет иконок iOS", category: "Дизайн", price: 249, description: "Авторский набор иконок для персонализации домашнего экрана." },
  { id: "wallpapers", name: "Обои для iPhone", category: "Дизайн", price: 99, description: "Коллекция оригинальных обоев для экрана iPhone." },
  { id: "iphone-checklist", name: "Чек-лист iPhone", category: "Инструкции", price: 129, description: "Список полезных настроек и рекомендаций для нового iPhone." }
];

app.get("/api/products", (_req, res) => res.json(products));

app.post("/api/orders", (req, res) => {
  const { items, telegramUser } = req.body ?? {};
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: "Корзина пуста" });
  }
  // TODO: validate Telegram initData on the server, recalculate prices from
  // the server-side catalog, save the order, and create a payment invoice
  // with a supported provider before accepting real payments.
  res.status(501).json({
    error: "Оплата ещё не подключена",
    message: "Это демонстрационная версия ADS STORE. Подключите платёжного провайдера и серверную проверку Telegram перед запуском продаж."
  });
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`ADS STORE is running on port ${port}`));
